package com.HubControl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HubControlApplication {

	public static void main(String[] args) {

		SpringApplication.run(HubControlApplication.class, args);

	}

}
