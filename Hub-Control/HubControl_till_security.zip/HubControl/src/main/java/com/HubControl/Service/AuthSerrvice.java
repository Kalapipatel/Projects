package com.HubControl.Service;

public interface AuthSerrvice {
}
