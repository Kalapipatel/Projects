package com.HubControl.Entity;

public enum PickingTaskStatus {
    PROCESSING,
    COMPLETED,
    ISSUE
}