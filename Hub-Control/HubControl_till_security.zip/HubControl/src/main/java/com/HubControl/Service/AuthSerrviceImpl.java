package com.HubControl.Service;

import org.springframework.stereotype.Service;

@Service
public class AuthSerrviceImpl {
}
