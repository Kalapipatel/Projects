package com.HubControl.Repo;

import com.HubControl.Entity.InventoryBatch;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryBatchRepository extends JpaRepository<InventoryBatch, Integer> {
}
