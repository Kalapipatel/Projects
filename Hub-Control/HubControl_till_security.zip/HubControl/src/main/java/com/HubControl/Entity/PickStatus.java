package com.HubControl.Entity;

public enum PickStatus {
    PENDING,
    PICKED,
    NOTFOUND,
    SUBSTITUTED
}