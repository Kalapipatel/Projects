package com.HubControl.Entity;

public enum OrderStatus {
    PENDING,
    PROCESSING,
    COMPLETED
}

